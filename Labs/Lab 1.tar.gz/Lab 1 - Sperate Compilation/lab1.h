#include <iostream> //List of things that go in header file
			//Includes
			//Costants, Defines, Macros
			//Data Structures (double points off)
			//Global Variables
			//Function Prototypes
using namespace std;
int readData(int[],int);
void sortData(int[],int);
void printData(int[],int);

